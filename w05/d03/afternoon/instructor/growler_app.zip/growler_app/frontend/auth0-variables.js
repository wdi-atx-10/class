var AUTH0_CLIENT_ID='wK6NgjR6LshD5DW84vBpchM4jd24DA5b';
var AUTH0_DOMAIN='dirkdunn.auth0.com';
var AUTH0_CALLBACK_URL=window.location.href;
